const TelegramBot = require('node-telegram-bot-api');

const token = '8083330294:AAFZ6QQBN3FmBMQmPLhZX4XzbGQQu78CLEA';
const bot = new TelegramBot(token, { polling: true });

bot.onText(/\/start/, (msg) => {
  const chatId = msg.chat.id;
  bot.sendMessage(chatId, 'Hoş geldin kumarbaz! Jetonların yükleniyor...');
});